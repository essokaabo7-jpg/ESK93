# ESK93 — Projet Android complet (prêt à compiler en APK)

Ce dossier contient le projet Android natif (WebView + Capacitor) généré à partir de ton archive `esk93-public`, avec la correction anti-blocage du profil (`Termine ton profil`) déjà intégrée.

## Contenu du projet
- `android/app/src/main/AndroidManifest.xml` : Permissions Internet, stockage/galerie photo et configuration de l'application `ESK93`.
- `android/app/src/main/java/com/esk93/app/MainActivity.java` : Activité native Android configurée avec JavaScript, stockage local Firebase (`DOMStorage`) et sélecteur de photos multiple pour publier les annonces.
- `android/app/src/main/assets/public/` & `www/` : Ton application complète (`index.html` corrigé, `manifest.webmanifest`, `sw.js`, icônes).
- `android/app/src/main/res/mipmap-*/` : Icônes d'application Android (`ic_launcher.png`).
- `capacitor.config.json` & `package.json` : Configuration Capacitor si tu souhaites compiler via CLI.

## Comment générer l'APK sur téléphone ou PC

### Option 1 : Directement sur Android (avec AIDE, AndroidIDE ou Termux)
1. Extrais ce fichier ZIP dans ton stockage interne.
2. Ouvre le dossier `android/` dans **AndroidIDE** ou **AIDE** (ou lance `gradle assembleDebug` dans Termux).
3. Le fichier `.apk` installable sera généré dans `android/app/build/outputs/apk/debug/app-debug.apk`.

### Option 2 : En ligne (sans PC, via GitHub Actions ou PWABuilder)
- **PWABuilder (le plus rapide sur téléphone)** : Héberge le contenu du dossier `www/` sur Firebase Hosting (`firebase deploy`), puis colle le lien sur [pwabuilder.com](https://www.pwabuilder.com) pour télécharger directement ton fichier `.apk` signé prêt à installer.
- **GitHub + Codemagic / GitHub Actions** : Importe ce dossier sur un dépôt GitHub et lance un build Gradle Android gratuit dans le cloud pour récupérer l'APK.

### Option 3 : Sur PC avec Android Studio
1. Ouvre Android Studio → **Open** → sélectionne le dossier `android/`.
2. Clique sur **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
