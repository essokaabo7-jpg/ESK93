window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyDQe-dIQvIkXJ8g-zrLv0sQIJsiAbEuqAw",
  authDomain: "esk93-db257.firebaseapp.com",
  projectId: "esk93-db257",
  storageBucket: "esk93-db257.firebasestorage.app",
  messagingSenderId: "357584635178",
  appId: "1:357584635178:web:e5bad68d2babb62623ca53",
  measurementId: "G-C8B9KVEFE7"
};
// Remplace par TON e-mail d'administrateur (il verra toutes les commissions).
window.ADMIN_EMAIL = "essokaabo7@gmail.com";
