// Service worker minimal : permet d'installer ESK93 sur l'écran d'accueil.
// Aucune mise en cache : l'application est toujours à jour.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});
